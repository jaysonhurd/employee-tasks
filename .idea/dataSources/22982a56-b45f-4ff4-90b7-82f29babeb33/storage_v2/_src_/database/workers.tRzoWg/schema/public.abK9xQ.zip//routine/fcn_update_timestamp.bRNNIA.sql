create function fcn_update_timestamp() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.create_time = NOW();
    RETURN NEW;
END;
$$;

alter function fcn_update_timestamp() owner to myusername;

